export const config = {
	apiUrl : 'http://localhost:3000/api/v1/'
}